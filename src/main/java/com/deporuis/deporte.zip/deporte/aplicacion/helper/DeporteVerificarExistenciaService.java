package com.deporuis.deporte.aplicacion.helper;

import com.deporuis.deporte.dominio.Deporte;
import com.deporuis.deporte.excepciones.DeporteNotFoundException;
import com.deporuis.deporte.excepciones.DeporteYaExisteException;
import com.deporuis.deporte.infraestructura.DeporteRepository;
import com.deporuis.shared.util.TextoUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class DeporteVerificarExistenciaService {

    @Autowired
    private DeporteRepository deporteRepository;

    @Transactional(readOnly = true)
    public Deporte verificarDeporte(Integer id) {
        Optional<Deporte> deporte = deporteRepository.findById(id);

        if (deporte.isEmpty()) {
            throw new DeporteNotFoundException("No se encontro Deporte con ID = " + id);
        }

        return deporte.get();
    }

    @Transactional(readOnly = true)
    public void verificarDeporteNoExiste(String nombreDeporte) {
        String nombreNormalizado = TextoUtil.quitarAcentos(nombreDeporte).toLowerCase();

        List<Deporte> deportes = deporteRepository.findAll();

        boolean existe = deportes.stream()
                .anyMatch(d -> TextoUtil.quitarAcentos(d.getNombreDeporte()).toLowerCase().equals(nombreNormalizado)
                        && Boolean.TRUE.equals(d.getVisibilidad()));

        if (existe) {
            throw new DeporteYaExisteException("El deporte '" + nombreDeporte + "' ya existe en la base de datos.");
        }
    }

}
