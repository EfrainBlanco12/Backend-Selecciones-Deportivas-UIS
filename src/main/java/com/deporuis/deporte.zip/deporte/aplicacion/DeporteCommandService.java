package com.deporuis.deporte.aplicacion;

import com.deporuis.deporte.aplicacion.helper.DeporteVerificarExistenciaService;
import com.deporuis.deporte.dominio.Deporte;
import com.deporuis.deporte.excepciones.DeporteNotFoundException;
import com.deporuis.deporte.excepciones.DeporteYaExisteException;
import com.deporuis.deporte.infraestructura.DeporteRepository;
import com.deporuis.deporte.infraestructura.dto.DeporteRequest;
import com.deporuis.deporte.infraestructura.dto.DeporteResponse;
import com.deporuis.shared.util.TextoUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;


@Service
public class DeporteCommandService {

    @Autowired
    private DeporteRepository deporteRepository;

    @Autowired
    private DeporteQueryService deporteQueryService;

    @Autowired
    private DeporteVerificarExistenciaService deporteVerificarExistenciaService;

    @Transactional
    public Optional<Deporte> verificarDeporteNoExisteYReactivarSiAplica(DeporteRequest deporteRequest) {
        Optional<Deporte> deporteExistente = deporteQueryService.buscarPorNombreNormalizado(deporteRequest.getNombreDeporte());

        if (deporteExistente.isPresent()) {
            Deporte deporte = deporteExistente.get();

            if (Boolean.TRUE.equals(deporte.getVisibilidad())) {
                throw new DeporteYaExisteException("El deporte '" + deporteRequest.getNombreDeporte() + "' ya existe en la base de datos.");
            } else {
                deporte.setVisibilidad(true);
                deporte.setDescripcionDeporte(deporteRequest.getDescripcionDeporte());
                return Optional.of(deporteRepository.save(deporte));
            }
        }
        return Optional.empty();
    }


    @Transactional
    public DeporteResponse actualizarDeporte(Integer idDeporte, DeporteRequest deporteRequest) {
        Deporte deporteExistente = deporteQueryService.buscarPorId(idDeporte)
                .orElseThrow(() -> new DeporteNotFoundException("Deporte no encontrado con ID: " + idDeporte));

        String nombreNuevoNormalizado = TextoUtil.quitarAcentos(deporteRequest.getNombreDeporte().toLowerCase());

        boolean yaExiste = deporteQueryService.existeNombreNormalizadoExcluyendoId(nombreNuevoNormalizado, idDeporte);
        if (yaExiste) {
            throw new DeporteYaExisteException("No se puede actualizar, ya existe un deporte con el nombre '" + deporteRequest.getNombreDeporte() + "'.");
        }

        deporteExistente.setNombreDeporte(deporteRequest.getNombreDeporte());
        deporteExistente.setDescripcionDeporte(deporteRequest.getDescripcionDeporte());

        Deporte deporteActualizado = deporteRepository.save(deporteExistente);
        return new DeporteResponse(deporteActualizado);
    }

}
