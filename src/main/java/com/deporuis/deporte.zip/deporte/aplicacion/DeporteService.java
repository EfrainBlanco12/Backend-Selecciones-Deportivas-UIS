package com.deporuis.deporte.aplicacion;

import com.deporuis.deporte.dominio.Deporte;
import com.deporuis.deporte.infraestructura.DeporteRepository;
import com.deporuis.deporte.infraestructura.dto.DeporteRequest;
import com.deporuis.deporte.infraestructura.dto.DeporteResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class DeporteService {

    @Autowired
    private DeporteRepository deporteRepository;

    @Autowired
    private DeporteCommandService deporteCommandService;

    @Transactional
    public DeporteResponse crearDeporte(DeporteRequest deporteRequest) {
        Optional<Deporte> deporteReactivado =
                deporteCommandService.verificarDeporteNoExisteYReactivarSiAplica(deporteRequest);

        if (deporteReactivado.isPresent()) {
            Deporte deporte = deporteReactivado.get();
            return new DeporteResponse(deporte.getIdDeporte(), deporte.getNombreDeporte());
        }

        Deporte nuevoDeporte = new Deporte(deporteRequest.getNombreDeporte(), deporteRequest.getDescripcionDeporte());
        Deporte deporteGuardado = deporteRepository.save(nuevoDeporte);
        return new DeporteResponse(deporteGuardado.getIdDeporte(), deporteGuardado.getNombreDeporte());
    }

}
